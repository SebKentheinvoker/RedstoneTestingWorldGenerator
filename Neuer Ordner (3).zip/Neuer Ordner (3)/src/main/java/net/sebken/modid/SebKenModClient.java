package net.sebken.modid;

 import net.fabricmc.api.ClientModInitializer;

public class SebKenModClient implements ClientModInitializer{
    @Override
    public void onInitializeClient () {

    }
}

